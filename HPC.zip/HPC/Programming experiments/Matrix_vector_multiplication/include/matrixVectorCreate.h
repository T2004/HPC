#ifndef MATRIX_VECTOR_CREATE_H
#define MATRIX_VECTOR_CREATE_H

void matrixVectorCreate(double **mat, double **vect, int rows, int cols);

#endif // MATRIX_VECTOR_CREATE_H