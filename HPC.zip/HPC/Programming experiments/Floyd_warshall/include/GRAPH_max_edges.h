#ifndef GRAPH_MAX_EDGES_H
#define GRAPH_MAX_EDGES_H

// Formula to calculate the number of possible edges in a graph
int GRAPH_max_edges(int vertices, int isDirected);

#endif // GRAPH_MAX_EDGES_H