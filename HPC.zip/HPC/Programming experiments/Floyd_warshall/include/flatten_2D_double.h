#ifndef FLATTEN_2D_DOUBLE_H
#define FLATTEN_2D_DOUBLE_H

void flatten_2D_double(const double * const *input, double **output, const int size);

#endif // FLATTEN_2D_DOUBLE_H